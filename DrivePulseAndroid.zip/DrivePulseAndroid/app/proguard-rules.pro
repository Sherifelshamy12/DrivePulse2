# Keep Room entities and DAOs
-keep class com.drivepulse.app.data.** { *; }
