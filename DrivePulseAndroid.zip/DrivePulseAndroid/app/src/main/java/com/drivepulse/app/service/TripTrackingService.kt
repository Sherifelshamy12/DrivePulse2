package com.drivepulse.app.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.location.Location
import android.os.Build
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.drivepulse.app.data.AppDatabase
import com.drivepulse.app.data.TripEntity
import com.drivepulse.app.domain.DrivingPatternAnalyzer
import com.drivepulse.app.sensors.BrakingDetector
import com.drivepulse.app.sensors.MotionPeakEvent
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class TripStatus { IDLE, RUNNING, PAUSED }

data class LiveTripState(
    val status: TripStatus = TripStatus.IDLE,
    val currentSpeedKmh: Float = 0f,
    val topSpeedKmh: Float = 0f,
    val avgSpeedKmh: Float = 0f,
    val distanceKm: Double = 0.0,
    val durationSec: Long = 0L,
    val totalBrakes: Int = 0,
    val harshBrakes: Int = 0,
    val currentAccelMs2: Float = 0f,
    val topAccelMs2: Float = 0f,
    val currentDecelMs2: Float = 0f,
    val topDecelMs2: Float = 0f,
    val accelEvents: List<MotionPeakEvent> = emptyList(),
    val decelEvents: List<MotionPeakEvent> = emptyList(),
    val liveScore: Int = 100,
    val livePattern: String = "Ready"
)

class TripTrackingService : Service() {

    companion object {
        const val ACTION_START = "com.drivepulse.app.ACTION_START"
        const val ACTION_PAUSE = "com.drivepulse.app.ACTION_PAUSE"
        const val ACTION_RESUME = "com.drivepulse.app.ACTION_RESUME"
        const val ACTION_STOP_AND_SAVE = "com.drivepulse.app.ACTION_STOP_AND_SAVE"

        const val EXTRA_HARSH_THRESHOLD = "extra_harsh_threshold"
        const val EXTRA_SPEED_LIMIT_KMH = "extra_speed_limit_kmh"

        private const val CHANNEL_ID = "drivepulse_tracking_channel"
        private const val NOTIFICATION_ID = 1001

        private val _liveState = MutableStateFlow(LiveTripState())
        val liveState: StateFlow<LiveTripState> = _liveState.asStateFlow()

        fun sendCommand(
            context: Context,
            action: String,
            harshThreshold: Float = 4.0f,
            speedLimitKmh: Float = 110f
        ) {
            val intent = Intent(context, TripTrackingService::class.java).apply {
                this.action = action
                putExtra(EXTRA_HARSH_THRESHOLD, harshThreshold)
                putExtra(EXTRA_SPEED_LIMIT_KMH, speedLimitKmh)
            }
            if (action == ACTION_START && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var brakingDetector: BrakingDetector

    private var timerJob: Job? = null
    private var lastLocation: Location? = null
    private var lastLocationTimeMs: Long = 0L
    private var lastSpeedKmh: Float = 0f
    private var startedAtMillis: Long = 0L
    private var speedLimitKmh: Float = 110f
    private val speedSamples = mutableListOf<Float>()

    private val locationCallback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            val loc = result.lastLocation ?: return
            if (_liveState.value.status != TripStatus.RUNNING) return

            val now = System.currentTimeMillis()
            val speedKmh = if (loc.hasSpeed()) loc.speed * 3.6f else 0f
            brakingDetector.isVehicleMoving = speedKmh > 8f

            if (lastLocationTimeMs > 0L) {
                val deltaSec = (now - lastLocationTimeMs) / 1000f
                brakingDetector.processGpsSpeedChange(lastSpeedKmh, speedKmh, deltaSec)
            }

            var addedKm = 0.0
            lastLocation?.let { prev ->
                val meters = prev.distanceTo(loc)
                if (meters in 1.5f..500f) {
                    addedKm = meters / 1000.0
                }
            }

            lastLocation = loc
            lastLocationTimeMs = now
            lastSpeedKmh = speedKmh
            speedSamples.add(speedKmh)

            _liveState.update { current ->
                val newDist = current.distanceKm + addedKm
                val newTop = maxOf(current.topSpeedKmh, speedKmh)
                val newAvg = if (speedSamples.isNotEmpty()) speedSamples.average().toFloat() else 0f
                val score = DrivingPatternAnalyzer.computeTripScore(
                    topSpeedKmh = newTop,
                    distanceKm = newDist,
                    totalBrakes = current.totalBrakes,
                    harshBrakes = current.harshBrakes,
                    speedSamplesKmh = speedSamples,
                    speedLimitKmh = speedLimitKmh
                )
                current.copy(
                    currentSpeedKmh = speedKmh,
                    topSpeedKmh = newTop,
                    avgSpeedKmh = newAvg,
                    distanceKm = newDist,
                    liveScore = score,
                    livePattern = DrivingPatternAnalyzer.classifyPattern(score)
                )
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        brakingDetector = BrakingDetector(
            context = this,
            onBrakeDetected = { event ->
                _liveState.update { current ->
                    val newTotal = current.totalBrakes + 1
                    val newHarsh = current.harshBrakes + if (event.isHarsh) 1 else 0
                    val score = DrivingPatternAnalyzer.computeTripScore(
                        topSpeedKmh = current.topSpeedKmh,
                        distanceKm = current.distanceKm,
                        totalBrakes = newTotal,
                        harshBrakes = newHarsh,
                        speedSamplesKmh = speedSamples,
                        speedLimitKmh = speedLimitKmh
                    )
                    current.copy(
                        totalBrakes = newTotal,
                        harshBrakes = newHarsh,
                        topDecelMs2 = maxOf(current.topDecelMs2, event.decelerationMs2),
                        liveScore = score,
                        livePattern = DrivingPatternAnalyzer.classifyPattern(score)
                    )
                }
            },
            onDecelUpdated = { decel ->
                _liveState.update { current ->
                    current.copy(
                        currentDecelMs2 = decel,
                        topDecelMs2 = maxOf(current.topDecelMs2, decel)
                    )
                }
            },
            onAccelUpdated = { accel ->
                _liveState.update { current ->
                    current.copy(
                        currentAccelMs2 = accel,
                        topAccelMs2 = maxOf(current.topAccelMs2, accel)
                    )
                }
            },
            onAccelPeakRecorded = { peak ->
                _liveState.update { current ->
                    val updated = (listOf(peak) + current.accelEvents)
                        .sortedByDescending { it.valueMs2 }
                        .take(15)
                    current.copy(
                        topAccelMs2 = maxOf(current.topAccelMs2, peak.valueMs2),
                        accelEvents = updated
                    )
                }
            },
            onDecelPeakRecorded = { peak ->
                _liveState.update { current ->
                    val updated = (listOf(peak) + current.decelEvents)
                        .sortedByDescending { it.valueMs2 }
                        .take(15)
                    current.copy(
                        topDecelMs2 = maxOf(current.topDecelMs2, peak.valueMs2),
                        decelEvents = updated
                    )
                }
            }
        )
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent?.let {
            brakingDetector.harshThresholdMs2 = it.getFloatExtra(EXTRA_HARSH_THRESHOLD, 4.0f)
            speedLimitKmh = it.getFloatExtra(EXTRA_SPEED_LIMIT_KMH, 110f)
        }

        when (intent?.action) {
            ACTION_START -> startTrip()
            ACTION_PAUSE -> pauseTrip()
            ACTION_RESUME -> resumeTrip()
            ACTION_STOP_AND_SAVE -> stopAndSaveTrip()
        }
        return START_STICKY
    }

    @SuppressLint("MissingPermission")
    private fun startTrip() {
        startedAtMillis = System.currentTimeMillis()
        lastLocation = null
        lastLocationTimeMs = 0L
        lastSpeedKmh = 0f
        speedSamples.clear()

        _liveState.value = LiveTripState(status = TripStatus.RUNNING, livePattern = "Smooth")
        startForeground(NOTIFICATION_ID, buildNotification("Recording trip • GPS active"))

        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000L)
            .setMinUpdateIntervalMillis(500L)
            .build()
        fusedLocationClient.requestLocationUpdates(request, locationCallback, Looper.getMainLooper())
        brakingDetector.start()
        startTimer()
    }

    private fun pauseTrip() {
        _liveState.update {
            it.copy(
                status = TripStatus.PAUSED,
                currentSpeedKmh = 0f,
                currentAccelMs2 = 0f,
                currentDecelMs2 = 0f
            )
        }
        timerJob?.cancel()
        brakingDetector.stop()
    }

    private fun resumeTrip() {
        _liveState.update { it.copy(status = TripStatus.RUNNING) }
        brakingDetector.start()
        startTimer()
    }

    private fun stopAndSaveTrip() {
        timerJob?.cancel()
        fusedLocationClient.removeLocationUpdates(locationCallback)
        brakingDetector.stop()

        val snapshot = _liveState.value
        val score = DrivingPatternAnalyzer.computeTripScore(
            topSpeedKmh = snapshot.topSpeedKmh,
            distanceKm = snapshot.distanceKm,
            totalBrakes = snapshot.totalBrakes,
            harshBrakes = snapshot.harshBrakes,
            speedSamplesKmh = speedSamples,
            speedLimitKmh = speedLimitKmh
        )
        val pattern = DrivingPatternAnalyzer.classifyPattern(score)
        val timeTitle = SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()).format(Date(startedAtMillis))

        serviceScope.launch {
            val dao = AppDatabase.getInstance(applicationContext).tripDao()
            dao.insertTrip(
                TripEntity(
                    title = "Drive • $timeTitle",
                    startedAtMillis = startedAtMillis,
                    durationSec = snapshot.durationSec.coerceAtLeast(1L),
                    distanceKm = snapshot.distanceKm,
                    topSpeedKmh = snapshot.topSpeedKmh,
                    avgSpeedKmh = snapshot.avgSpeedKmh,
                    totalBrakes = snapshot.totalBrakes,
                    harshBrakes = snapshot.harshBrakes,
                    score = score,
                    pattern = pattern,
                    topAccelMs2 = snapshot.topAccelMs2,
                    topDecelMs2 = snapshot.topDecelMs2
                )
            )
        }

        _liveState.value = LiveTripState(status = TripStatus.IDLE)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = serviceScope.launch {
            while (isActive) {
                delay(1000L)
                if (_liveState.value.status == TripStatus.RUNNING) {
                    _liveState.update { it.copy(durationSec = it.durationSec + 1L) }
                }
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Trip Tracking",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("DrivePulse")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setOngoing(true)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        timerJob?.cancel()
        fusedLocationClient.removeLocationUpdates(locationCallback)
        brakingDetector.stop()
        super.onDestroy()
    }
}
