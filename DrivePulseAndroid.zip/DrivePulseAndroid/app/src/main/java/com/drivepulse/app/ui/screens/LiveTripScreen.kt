package com.drivepulse.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drivepulse.app.service.LiveTripState
import com.drivepulse.app.service.TripStatus
import com.drivepulse.app.ui.UserSettings
import com.drivepulse.app.ui.theme.AmberWarn
import com.drivepulse.app.ui.theme.EmeraldSafe
import com.drivepulse.app.ui.theme.NavyBg
import com.drivepulse.app.ui.theme.RoseAlert
import com.drivepulse.app.ui.theme.SkyAccent
import com.drivepulse.app.ui.theme.SlateBorder
import com.drivepulse.app.ui.theme.SlateCard
import com.drivepulse.app.ui.theme.TextPrimary
import com.drivepulse.app.ui.theme.TextSecondary
import kotlin.math.min
import kotlin.math.roundToInt

@Composable
fun LiveTripScreen(
    liveState: LiveTripState,
    settings: UserSettings,
    hasLocationPermission: Boolean,
    onRequestPermission: () -> Unit,
    onStart: () -> Unit,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onStopAndSave: () -> Unit
) {
    val speedFactor = if (settings.useMph) 0.621371f else 1f
    val speedUnit = if (settings.useMph) "mph" else "km/h"
    val distUnit = if (settings.useMph) "mi" else "km"
    val displaySpeed = (liveState.currentSpeedKmh * speedFactor).roundToInt()
    val displayTop = (liveState.topSpeedKmh * speedFactor).roundToInt()
    val displayAvg = (liveState.avgSpeedKmh * speedFactor).roundToInt()
    val displayDist = liveState.distanceKm * speedFactor
    val brakeFreq = if (displayDist >= 0.1) liveState.totalBrakes / displayDist else 0.0
    val isOverLimit = liveState.status == TripStatus.RUNNING && liveState.currentSpeedKmh > settings.speedLimitKmh

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (!hasLocationPermission) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(AmberWarn.copy(alpha = 0.14f), RoundedCornerShape(16.dp))
                    .border(1.dp, AmberWarn.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Location permission is required for GPS speed.",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = onRequestPermission,
                        colors = ButtonDefaults.buttonColors(containerColor = AmberWarn, contentColor = NavyBg)
                    ) {
                        Text("Allow", fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        // Main Speedometer Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(SlateCard, RoundedCornerShape(24.dp))
                .border(1.dp, SlateBorder, RoundedCornerShape(24.dp))
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Live Telemetry", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                Text(
                    text = if (isOverLimit) "Over Speed Limit!" else "Pattern: ${liveState.livePattern}",
                    color = if (isOverLimit) RoseAlert else EmeraldSafe,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(Modifier.height(16.dp))

            // Circular Speedometer Gauge
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(200.dp)) {
                val ratio = min(1f, liveState.currentSpeedKmh / 160f)
                val arcColor = when {
                    isOverLimit -> RoseAlert
                    liveState.currentSpeedKmh > settings.speedLimitKmh * 0.8f -> AmberWarn
                    else -> SkyAccent
                }
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawArc(
                        color = Color(0xFF1E293B),
                        startAngle = 135f,
                        sweepAngle = 270f,
                        useCenter = false,
                        style = Stroke(width = 14.dp.toPx(), cap = StrokeCap.Round)
                    )
                    drawArc(
                        color = arcColor,
                        startAngle = 135f,
                        sweepAngle = 270f * ratio,
                        useCenter = false,
                        style = Stroke(width = 14.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "$displaySpeed",
                        color = TextPrimary,
                        fontSize = 48.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(text = speedUnit.uppercase(), color = TextSecondary, fontSize = 12.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = "Decel: %.1f m/s²".format(liveState.currentDecelMs2),
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            // Trip Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                when (liveState.status) {
                    TripStatus.IDLE -> {
                        Button(
                            onClick = {
                                if (hasLocationPermission) onStart() else onRequestPermission()
                            },
                            modifier = Modifier.fillMaxWidth().height(48.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = SkyAccent, contentColor = NavyBg)
                        ) {
                            Text("Start Trip", fontWeight = FontWeight.Bold)
                        }
                    }
                    TripStatus.RUNNING -> {
                        OutlinedButton(
                            onClick = onPause,
                            modifier = Modifier.weight(1f).height(48.dp),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Text("Pause", color = AmberWarn, fontWeight = FontWeight.SemiBold)
                        }
                        Button(
                            onClick = onStopAndSave,
                            modifier = Modifier.weight(1f).height(48.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = RoseAlert, contentColor = Color.White)
                        ) {
                            Text("End & Save", fontWeight = FontWeight.Bold)
                        }
                    }
                    TripStatus.PAUSED -> {
                        Button(
                            onClick = onResume,
                            modifier = Modifier.weight(1f).height(48.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = SkyAccent, contentColor = NavyBg)
                        ) {
                            Text("Resume", fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = onStopAndSave,
                            modifier = Modifier.weight(1f).height(48.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = RoseAlert, contentColor = Color.White)
                        ) {
                            Text("End & Save", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // 2x2 Metric Grid
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MetricTile(
                title = "Top Speed",
                value = "$displayTop $speedUnit",
                subtitle = "Avg: $displayAvg $speedUnit",
                modifier = Modifier.weight(1f)
            )
            MetricTile(
                title = "Braking Events",
                value = "${liveState.totalBrakes}",
                subtitle = "Harsh: ${liveState.harshBrakes} • %.1f/%s".format(brakeFreq, distUnit),
                modifier = Modifier.weight(1f)
            )
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MetricTile(
                title = "Distance",
                value = "%.2f %s".format(displayDist, distUnit),
                subtitle = "Foreground GPS",
                modifier = Modifier.weight(1f)
            )
            val mins = liveState.durationSec / 60
            val secs = liveState.durationSec % 60
            MetricTile(
                title = "Duration",
                value = "%02d:%02d".format(mins, secs),
                subtitle = "Score: ${liveState.liveScore}/100",
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun MetricTile(
    title: String,
    value: String,
    subtitle: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .background(SlateCard, RoundedCornerShape(20.dp))
            .border(1.dp, SlateBorder, RoundedCornerShape(20.dp))
            .padding(16.dp)
    ) {
        Text(title, color = TextSecondary, fontSize = 12.sp)
        Spacer(Modifier.height(6.dp))
        Text(value, color = TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(subtitle, color = TextSecondary, fontSize = 11.sp)
    }
}
