package com.drivepulse.app.sensors

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

data class BrakeEvent(
    val decelerationMs2: Float,
    val isHarsh: Boolean,
    val timestampMillis: Long
)

data class MotionPeakEvent(
    val valueMs2: Float,
    val fromSpeedKmh: Float,
    val toSpeedKmh: Float,
    val timestampMillis: Long,
    val isHarsh: Boolean = false
)

/**
 * Combines Android's TYPE_LINEAR_ACCELERATION sensor with GPS speed deltas
 * to measure live acceleration, live deceleration, peak bursts, and harsh braking.
 */
class BrakingDetector(
    context: Context,
    private val onBrakeDetected: (BrakeEvent) -> Unit,
    private val onDecelUpdated: (Float) -> Unit,
    private val onAccelUpdated: (Float) -> Unit = {},
    private val onAccelPeakRecorded: (MotionPeakEvent) -> Unit = {},
    private val onDecelPeakRecorded: (MotionPeakEvent) -> Unit = {}
) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val linearAccel: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION)

    @Volatile var harshThresholdMs2: Float = 4.0f
    @Volatile var normalThresholdMs2: Float = 2.0f
    @Volatile var isVehicleMoving: Boolean = false

    private var smoothedMagnitude = 0f
    private var lastBrakeTimestamp = 0L
    private var lastAccelEventTimestamp = 0L
    private val cooldownMs = 2500L

    fun start() {
        linearAccel?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    fun stop() {
        sensorManager.unregisterListener(this)
        smoothedMagnitude = 0f
        onDecelUpdated(0f)
        onAccelUpdated(0f)
    }

    /**
     * Evaluates GPS speed change (m/s^2) paired with linear accelerometer magnitude
     * so we reliably separate acceleration (+) from deceleration (-) regardless of phone mount angle.
     */
    fun processGpsSpeedChange(prevSpeedKmh: Float, currentSpeedKmh: Float, deltaSec: Float) {
        if (deltaSec <= 0.2f) return
        val deltaKmh = currentSpeedKmh - prevSpeedKmh
        val gpsRateMs2 = (deltaKmh / 3.6f) / deltaSec
        val now = System.currentTimeMillis()

        if (deltaKmh > 0.6f && currentSpeedKmh > 3f) {
            // Vehicle is accelerating
            val combinedAccel = min(14f, max(gpsRateMs2, smoothedMagnitude))
            onAccelUpdated(combinedAccel)
            onDecelUpdated(0f)
            if (combinedAccel >= 1.5f && now - lastAccelEventTimestamp >= cooldownMs) {
                lastAccelEventTimestamp = now
                onAccelPeakRecorded(
                    MotionPeakEvent(
                        valueMs2 = combinedAccel,
                        fromSpeedKmh = prevSpeedKmh,
                        toSpeedKmh = currentSpeedKmh,
                        timestampMillis = now
                    )
                )
            }
        } else if (deltaKmh < -0.6f && prevSpeedKmh > 5f) {
            // Vehicle is decelerating / braking
            val combinedDecel = min(14f, max(abs(gpsRateMs2), smoothedMagnitude))
            onDecelUpdated(combinedDecel)
            onAccelUpdated(0f)
            if (combinedDecel >= normalThresholdMs2) {
                emitBrakeIfReady(combinedDecel, prevSpeedKmh, currentSpeedKmh)
            }
        } else {
            onAccelUpdated(0f)
            onDecelUpdated(0f)
        }
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_LINEAR_ACCELERATION) return

        val ax = event.values[0]
        val ay = event.values[1]
        val az = event.values[2]
        val rawMag = sqrt(ax * ax + ay * ay + az * az)

        // Low-pass filter to ignore minor road vibration
        smoothedMagnitude = 0.8f * smoothedMagnitude + 0.2f * rawMag

        if (isVehicleMoving && smoothedMagnitude >= harshThresholdMs2) {
            emitBrakeIfReady(smoothedMagnitude, 0f, 0f)
        }
    }

    private fun emitBrakeIfReady(decelMs2: Float, fromSpeedKmh: Float, toSpeedKmh: Float) {
        val now = System.currentTimeMillis()
        if (now - lastBrakeTimestamp < cooldownMs) return
        lastBrakeTimestamp = now
        val isHarsh = decelMs2 >= harshThresholdMs2
        onBrakeDetected(
            BrakeEvent(
                decelerationMs2 = decelMs2,
                isHarsh = isHarsh,
                timestampMillis = now
            )
        )
        onDecelPeakRecorded(
            MotionPeakEvent(
                valueMs2 = decelMs2,
                fromSpeedKmh = fromSpeedKmh,
                toSpeedKmh = toSpeedKmh,
                timestampMillis = now,
                isHarsh = isHarsh
            )
        )
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
}
