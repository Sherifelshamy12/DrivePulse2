package com.drivepulse.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drivepulse.app.data.TripEntity
import com.drivepulse.app.ui.UserSettings
import com.drivepulse.app.ui.theme.EmeraldSafe
import com.drivepulse.app.ui.theme.RoseAlert
import com.drivepulse.app.ui.theme.SkyAccent
import com.drivepulse.app.ui.theme.SlateBorder
import com.drivepulse.app.ui.theme.SlateCard
import com.drivepulse.app.ui.theme.TextPrimary
import com.drivepulse.app.ui.theme.TextSecondary
import kotlin.math.roundToInt

@Composable
fun TripHistoryScreen(
    trips: List<TripEntity>,
    settings: UserSettings,
    onDeleteTrip: (Long) -> Unit
) {
    var selectedFilter by remember { mutableStateOf("All") }
    val filters = listOf("All", "Smooth", "Balanced", "Aggressive")
    val filtered = if (selectedFilter == "All") trips else trips.filter { it.pattern == selectedFilter }

    val factor = if (settings.useMph) 0.621371 else 1.0
    val speedUnit = if (settings.useMph) "mph" else "km/h"
    val distUnit = if (settings.useMph) "mi" else "km"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("Saved Trips", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            filters.forEach { label ->
                FilterChip(
                    selected = selectedFilter == label,
                    onClick = { selectedFilter = label },
                    label = { Text(label, fontSize = 12.sp) }
                )
            }
        }

        Spacer(Modifier.height(12.dp))

        if (filtered.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SlateCard, RoundedCornerShape(20.dp))
                    .border(1.dp, SlateBorder, RoundedCornerShape(20.dp))
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("No saved trips yet", color = TextPrimary, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Start and save a trip on the Live tab to see it here.",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(filtered, key = { it.id }) { trip ->
                    val dist = trip.distanceKm * factor
                    val brakeFreq = if (dist > 0.05) trip.totalBrakes / dist else 0.0
                    val badgeColor = when (trip.pattern) {
                        "Smooth" -> EmeraldSafe
                        "Balanced" -> SkyAccent
                        else -> RoseAlert
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(SlateCard, RoundedCornerShape(20.dp))
                            .border(1.dp, SlateBorder, RoundedCornerShape(20.dp))
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(trip.title, color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                            Text(
                                "${trip.pattern} • ${trip.score}",
                                color = badgeColor,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Top: ${(trip.topSpeedKmh * factor).roundToInt()} $speedUnit", color = TextSecondary, fontSize = 12.sp)
                            Text("Dist: %.2f %s".format(dist, distUnit), color = TextSecondary, fontSize = 12.sp)
                            Text("Brakes: ${trip.totalBrakes} (${trip.harshBrakes})", color = TextSecondary, fontSize = 12.sp)
                        }
                        Spacer(Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Top Accel: +%.1f m/s²".format(trip.topAccelMs2), color = EmeraldSafe, fontSize = 12.sp)
                            Text("Top Decel: -%.1f m/s²".format(trip.topDecelMs2), color = RoseAlert, fontSize = 12.sp)
                        }
                        Spacer(Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Freq: %.1f/%s".format(brakeFreq, distUnit), color = TextSecondary, fontSize = 12.sp)
                            TextButton(onClick = { onDeleteTrip(trip.id) }) {
                                Text("Delete", color = RoseAlert, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
