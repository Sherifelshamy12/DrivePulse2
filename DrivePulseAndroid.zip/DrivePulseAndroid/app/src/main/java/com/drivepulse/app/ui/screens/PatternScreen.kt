package com.drivepulse.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drivepulse.app.domain.OverallPatternSummary
import com.drivepulse.app.ui.UserSettings
import com.drivepulse.app.ui.theme.AmberWarn
import com.drivepulse.app.ui.theme.EmeraldSafe
import com.drivepulse.app.ui.theme.SkyAccent
import com.drivepulse.app.ui.theme.SlateBorder
import com.drivepulse.app.ui.theme.SlateCard
import com.drivepulse.app.ui.theme.TextPrimary
import com.drivepulse.app.ui.theme.TextSecondary
import kotlin.math.roundToInt

@Composable
fun PatternScreen(
    summary: OverallPatternSummary,
    tripCount: Int,
    settings: UserSettings,
    onHarshThresholdChange: (Float) -> Unit,
    onSpeedLimitChange: (Float) -> Unit
) {
    val factor = if (settings.useMph) 0.621371f else 1f
    val speedUnit = if (settings.useMph) "mph" else "km/h"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Overall Score Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(SlateCard, RoundedCornerShape(24.dp))
                .border(1.dp, SlateBorder, RoundedCornerShape(24.dp))
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("OVERALL DRIVING PROFILE", color = TextSecondary, fontSize = 11.sp)
                    Spacer(Modifier.height(4.dp))
                    Text(summary.patternLabel, color = TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("$tripCount trips analyzed", color = TextSecondary, fontSize = 12.sp)
                }
                Text(
                    text = if (tripCount > 0) "${summary.score}" else "--",
                    color = EmeraldSafe,
                    fontSize = 36.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(Modifier.height(16.dp))
            MetricBar("Braking Smoothness", summary.brakingSmoothnessPct, EmeraldSafe)
            Spacer(Modifier.height(10.dp))
            MetricBar("Top Speed Control", summary.speedControlPct, SkyAccent)
            Spacer(Modifier.height(10.dp))
            MetricBar("Speed Consistency", summary.consistencyPct, Color(0xFF818CF8))
            Spacer(Modifier.height(10.dp))
            MetricBar("Harsh Brake Avoidance", summary.harshAvoidancePct, AmberWarn)
        }

        // Insights Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(SlateCard, RoundedCornerShape(24.dp))
                .border(1.dp, SlateBorder, RoundedCornerShape(24.dp))
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Pattern Insights", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            summary.insights.forEach { tip ->
                Text("• $tip", color = TextSecondary, fontSize = 13.sp, lineHeight = 18.sp)
            }
        }

        // Sensor Calibration Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(SlateCard, RoundedCornerShape(24.dp))
                .border(1.dp, SlateBorder, RoundedCornerShape(24.dp))
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Sensor Thresholds", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)

            Column {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Harsh Brake Trigger", color = TextSecondary, fontSize = 13.sp)
                    Text("-%.1f m/s²".format(settings.harshBrakeThresholdMs2), color = SkyAccent, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                }
                Slider(
                    value = settings.harshBrakeThresholdMs2,
                    onValueChange = onHarshThresholdChange,
                    valueRange = 2.5f..5.5f,
                    steps = 5
                )
            }

            Column {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Speed Alert Limit", color = TextSecondary, fontSize = 13.sp)
                    Text("${(settings.speedLimitKmh * factor).roundToInt()} $speedUnit", color = SkyAccent, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                }
                Slider(
                    value = settings.speedLimitKmh,
                    onValueChange = onSpeedLimitChange,
                    valueRange = 70f..140f,
                    steps = 13
                )
            }
        }
    }
}

@Composable
private fun MetricBar(label: String, pct: Int, color: Color) {
    Column {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = TextSecondary, fontSize = 12.sp)
            Text("$pct%", color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
        }
        Spacer(Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { (pct / 100f).coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(7.dp),
            color = color,
            trackColor = SlateBorder
        )
    }
}
