package com.drivepulse.app.domain

import com.drivepulse.app.data.TripEntity
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class OverallPatternSummary(
    val score: Int,
    val patternLabel: String,
    val brakingSmoothnessPct: Int,
    val speedControlPct: Int,
    val consistencyPct: Int,
    val harshAvoidancePct: Int,
    val insights: List<String>
)

object DrivingPatternAnalyzer {

    fun computeTripScore(
        topSpeedKmh: Float,
        distanceKm: Double,
        totalBrakes: Int,
        harshBrakes: Int,
        speedSamplesKmh: List<Float>,
        speedLimitKmh: Float
    ): Int {
        val safeDist = max(distanceKm, 0.3)
        val brakeFreq = totalBrakes / safeDist
        var score = 100.0

        // Harsh braking penalty
        score -= harshBrakes * 8.0

        // Braking frequency penalty above 0.8 brakes/km
        if (brakeFreq > 0.8) {
            score -= min(20.0, (brakeFreq - 0.8) * 9.0)
        }

        // Top speed penalty above configured limit
        if (topSpeedKmh > speedLimitKmh) {
            score -= min(22.0, (topSpeedKmh - speedLimitKmh) * 0.7)
        }

        // Speed variance penalty
        if (speedSamplesKmh.size > 4) {
            var sumDelta = 0.0
            for (i in 1 until speedSamplesKmh.size) {
                sumDelta += abs(speedSamplesKmh[i] - speedSamplesKmh[i - 1])
            }
            val avgDelta = sumDelta / (speedSamplesKmh.size - 1)
            if (avgDelta > 8.0) {
                score -= min(15.0, (avgDelta - 8.0) * 1.1)
            }
        }

        return score.roundToInt().coerceIn(25, 100)
    }

    fun classifyPattern(score: Int): String = when {
        score >= 85 -> "Smooth"
        score >= 70 -> "Balanced"
        else -> "Aggressive"
    }

    fun summarizeAllTrips(
        trips: List<TripEntity>,
        speedLimitKmh: Float,
        useMph: Boolean
    ): OverallPatternSummary {
        if (trips.isEmpty()) {
            return OverallPatternSummary(
                score = 0,
                patternLabel = "No Trips Yet",
                brakingSmoothnessPct = 0,
                speedControlPct = 0,
                consistencyPct = 0,
                harshAvoidancePct = 0,
                insights = listOf("Record your first trip to unlock personalized driving pattern insights.")
            )
        }

        val count = trips.size
        val avgScore = trips.map { it.score }.average().roundToInt()
        val totalKm = max(0.1, trips.sumOf { it.distanceKm })
        val totalBrakes = trips.sumOf { it.totalBrakes }
        val totalHarsh = trips.sumOf { it.harshBrakes }
        val maxTopSpeed = trips.maxOf { it.topSpeedKmh }
        val avgBrakesPerKm = totalBrakes / totalKm

        val brakingSmoothness = (100 - avgBrakesPerKm * 32).roundToInt().coerceIn(25, 100)
        val speedControl = (100 - max(0f, maxTopSpeed - speedLimitKmh) * 1.6f).roundToInt().coerceIn(30, 100)
        val consistency = (avgScore * 0.96 + 3).roundToInt().coerceIn(35, 100)
        val harshAvoidance = (100 - (totalHarsh.toDouble() / count) * 18).roundToInt().coerceIn(20, 100)

        val unitSpeed = if (useMph) "mph" else "km/h"
        val unitDist = if (useMph) "mi" else "km"
        val factor = if (useMph) 0.621371 else 1.0

        val insights = buildList {
            val harshPerTrip = totalHarsh.toDouble() / count
            if (harshPerTrip >= 1.5) {
                add("Averaging %.1f harsh brakes per trip. Leaving 1–2 extra seconds of following distance cuts sudden stops.".format(harshPerTrip))
            } else {
                add("Low harsh-braking rate (%.1f per trip). Smooth deceleration helps reduce brake wear.".format(harshPerTrip))
            }

            if (maxTopSpeed > speedLimitKmh) {
                add("Peak recorded speed reached %d %s, above your %d %s speed alert.".format(
                    (maxTopSpeed * factor).roundToInt(),
                    unitSpeed,
                    (speedLimitKmh * factor).roundToInt(),
                    unitSpeed
                ))
            } else {
                add("All saved trips stayed within your %d %s speed limit threshold.".format(
                    (speedLimitKmh * factor).roundToInt(),
                    unitSpeed
                ))
            }

            val freqInUnit = if (useMph) avgBrakesPerKm / 0.621371 else avgBrakesPerKm
            add("Overall braking frequency is %.2f brakes/%s across %.1f %s tracked.".format(
                freqInUnit,
                unitDist,
                totalKm * factor,
                unitDist
            ))
        }

        return OverallPatternSummary(
            score = avgScore,
            patternLabel = "${classifyPattern(avgScore)} Driver",
            brakingSmoothnessPct = brakingSmoothness,
            speedControlPct = speedControl,
            consistencyPct = consistency,
            harshAvoidancePct = harshAvoidance,
            insights = insights
        )
    }
}
