package com.drivepulse.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val NavyBg = Color(0xFF0B1120)
val SlateCard = Color(0xFF0F172A)
val SlateBorder = Color(0xFF1E293B)
val SkyAccent = Color(0xFF38BDF8)
val EmeraldSafe = Color(0xFF34D399)
val AmberWarn = Color(0xFFF59E0B)
val RoseAlert = Color(0xFFFB7185)
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)

private val DrivePulseDarkScheme = darkColorScheme(
    primary = SkyAccent,
    onPrimary = NavyBg,
    secondary = EmeraldSafe,
    background = NavyBg,
    surface = SlateCard,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    error = RoseAlert
)

@Composable
fun DrivePulseTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DrivePulseDarkScheme,
        content = content
    )
}
