package com.drivepulse.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.drivepulse.app.ui.TripViewModel
import com.drivepulse.app.ui.screens.LiveTripScreen
import com.drivepulse.app.ui.screens.PatternScreen
import com.drivepulse.app.ui.screens.TopAccelScreen
import com.drivepulse.app.ui.screens.TopDecelScreen
import com.drivepulse.app.ui.screens.TripHistoryScreen
import com.drivepulse.app.ui.theme.DrivePulseTheme
import com.drivepulse.app.ui.theme.NavyBg
import com.drivepulse.app.ui.theme.SkyAccent
import com.drivepulse.app.ui.theme.SlateCard
import com.drivepulse.app.ui.theme.TextPrimary

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DrivePulseTheme {
                DrivePulseRoot()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DrivePulseRoot(viewModel: TripViewModel = viewModel()) {
    val context = LocalContext.current
    val liveState by viewModel.liveTripState.collectAsStateWithLifecycle()
    val trips by viewModel.trips.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val summary by viewModel.patternSummary.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableIntStateOf(0) }
    var hasLocationPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        hasLocationPermission = grants[Manifest.permission.ACCESS_FINE_LOCATION] == true
    }

    val requestPermissions = {
        val perms = buildList {
            add(Manifest.permission.ACCESS_FINE_LOCATION)
            add(Manifest.permission.ACCESS_COARSE_LOCATION)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }.toTypedArray()
        permissionLauncher.launch(perms)
    }

    Scaffold(
        containerColor = NavyBg,
        topBar = {
            TopAppBar(
                title = { Text("DrivePulse", fontWeight = FontWeight.Bold, color = TextPrimary) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SlateCard),
                actions = {
                    TextButton(onClick = viewModel::toggleUnits) {
                        Text(
                            text = if (settings.useMph) "mph" else "km/h",
                            color = SkyAccent,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar(containerColor = SlateCard) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.DirectionsCar, contentDescription = "Live") },
                    label = { Text("Live") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.TrendingUp, contentDescription = "Accel") },
                    label = { Text("Accel") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.TrendingDown, contentDescription = "Decel") },
                    label = { Text("Decel") }
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.History, contentDescription = "Trips") },
                    label = { Text("Trips") }
                )
                NavigationBarItem(
                    selected = selectedTab == 4,
                    onClick = { selectedTab = 4 },
                    icon = { Icon(Icons.Default.Insights, contentDescription = "Pattern") },
                    label = { Text("Pattern") }
                )
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding)) {
            when (selectedTab) {
                0 -> LiveTripScreen(
                    liveState = liveState,
                    settings = settings,
                    hasLocationPermission = hasLocationPermission,
                    onRequestPermission = requestPermissions,
                    onStart = viewModel::startTrip,
                    onPause = viewModel::pauseTrip,
                    onResume = viewModel::resumeTrip,
                    onStopAndSave = viewModel::stopAndSaveTrip
                )
                1 -> TopAccelScreen(
                    liveState = liveState,
                    trips = trips,
                    settings = settings
                )
                2 -> TopDecelScreen(
                    liveState = liveState,
                    trips = trips,
                    settings = settings
                )
                3 -> TripHistoryScreen(
                    trips = trips,
                    settings = settings,
                    onDeleteTrip = viewModel::deleteTrip
                )
                4 -> PatternScreen(
                    summary = summary,
                    tripCount = trips.size,
                    settings = settings,
                    onHarshThresholdChange = viewModel::updateHarshBrakeThreshold,
                    onSpeedLimitChange = viewModel::updateSpeedLimitKmh
                )
            }
        }
    }
}
