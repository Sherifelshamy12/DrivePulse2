package com.drivepulse.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drivepulse.app.data.TripEntity
import com.drivepulse.app.service.LiveTripState
import com.drivepulse.app.service.TripStatus
import com.drivepulse.app.ui.UserSettings
import com.drivepulse.app.ui.theme.AmberWarn
import com.drivepulse.app.ui.theme.EmeraldSafe
import com.drivepulse.app.ui.theme.RoseAlert
import com.drivepulse.app.ui.theme.SkyAccent
import com.drivepulse.app.ui.theme.SlateBorder
import com.drivepulse.app.ui.theme.SlateCard
import com.drivepulse.app.ui.theme.TextPrimary
import com.drivepulse.app.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun TopAccelScreen(
    liveState: LiveTripState,
    trips: List<TripEntity>,
    settings: UserSettings
) {
    val speedFactor = if (settings.useMph) 0.621371f else 1f
    val speedUnit = if (settings.useMph) "mph" else "km/h"
    val topAccel = liveState.topAccelMs2
    val topG = topAccel / 9.81f
    val allTimeTop = maxOf(topAccel, trips.maxOfOrNull { it.topAccelMs2 } ?: 0f)

    val ratingLabel = when {
        topAccel >= 4.5f -> "Aggressive Launch"
        topAccel >= 3.0f -> "Brisk Acceleration"
        topAccel > 0.1f -> "Smooth Acceleration"
        else -> "Waiting for Trip"
    }
    val ratingColor = when {
        topAccel >= 4.5f -> RoseAlert
        topAccel >= 3.0f -> AmberWarn
        topAccel > 0.1f -> EmeraldSafe
        else -> TextSecondary
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Top Acceleration", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)

        // Hero Peak Acceleration Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(SlateCard, RoundedCornerShape(24.dp))
                .border(1.dp, SlateBorder, RoundedCornerShape(24.dp))
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (liveState.status == TripStatus.IDLE) "CURRENT TRIP PEAK" else "LIVE TRIP PEAK",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(ratingLabel, color = ratingColor, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }

            Spacer(Modifier.height(10.dp))

            Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "+%.2f".format(topAccel),
                    color = EmeraldSafe,
                    fontSize = 44.sp,
                    fontWeight = FontWeight.Bold
                )
                Text("m/s²", color = TextSecondary, fontSize = 16.sp, modifier = Modifier.padding(bottom = 8.dp))
                Text(
                    text = "(%.2f g)".format(topG),
                    color = SkyAccent,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
            }

            Spacer(Modifier.height(14.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Live Accel: +%.1f m/s²".format(liveState.currentAccelMs2), color = TextSecondary, fontSize = 12.sp)
                Text("All-Time Best: +%.2f m/s²".format(allTimeTop), color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { (liveState.currentAccelMs2 / 6.0f).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(8.dp),
                color = EmeraldSafe,
                trackColor = SlateBorder
            )
        }

        // Peak Bursts in Active Trip
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(SlateCard, RoundedCornerShape(20.dp))
                .border(1.dp, SlateBorder, RoundedCornerShape(20.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Strongest Bursts (This Trip)", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)

            if (liveState.accelEvents.isEmpty()) {
                Text(
                    text = "Start a trip and accelerate to log your top acceleration bursts here.",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            } else {
                val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
                liveState.accelEvents.take(6).forEachIndexed { idx, ev ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(SlateBorder.copy(alpha = 0.45f), RoundedCornerShape(14.dp))
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                "#${idx + 1}  +%.2f m/s² (%.2f g)".format(ev.valueMs2, ev.valueMs2 / 9.81f),
                                color = EmeraldSafe,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                "${(ev.fromSpeedKmh * speedFactor).roundToInt()} → ${(ev.toSpeedKmh * speedFactor).roundToInt()} $speedUnit",
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                        Text(timeFmt.format(Date(ev.timestampMillis)), color = TextSecondary, fontSize = 11.sp)
                    }
                }
            }
        }

        // Saved Trips Top Acceleration History
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(SlateCard, RoundedCornerShape(20.dp))
                .border(1.dp, SlateBorder, RoundedCornerShape(20.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Top Acceleration by Saved Trip", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            if (trips.isEmpty()) {
                Text("No saved trips yet.", color = TextSecondary, fontSize = 12.sp)
            } else {
                trips.take(8).forEach { trip ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(trip.title, color = TextPrimary, fontSize = 13.sp)
                        Text(
                            "+%.2f m/s² (%.2f g)".format(trip.topAccelMs2, trip.topAccelMs2 / 9.81f),
                            color = EmeraldSafe,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}
