package com.drivepulse.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "trips")
data class TripEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val startedAtMillis: Long,
    val durationSec: Long,
    val distanceKm: Double,
    val topSpeedKmh: Float,
    val avgSpeedKmh: Float,
    val totalBrakes: Int,
    val harshBrakes: Int,
    val score: Int,
    val pattern: String,
    val topAccelMs2: Float = 0f,
    val topDecelMs2: Float = 0f
)
