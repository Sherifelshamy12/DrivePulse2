package com.drivepulse.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.drivepulse.app.data.AppDatabase
import com.drivepulse.app.data.TripEntity
import com.drivepulse.app.domain.DrivingPatternAnalyzer
import com.drivepulse.app.domain.OverallPatternSummary
import com.drivepulse.app.service.LiveTripState
import com.drivepulse.app.service.TripTrackingService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class UserSettings(
    val useMph: Boolean = false,
    val harshBrakeThresholdMs2: Float = 4.0f,
    val speedLimitKmh: Float = 110f
)

class TripViewModel(application: Application) : AndroidViewModel(application) {

    private val tripDao = AppDatabase.getInstance(application).tripDao()

    val liveTripState: StateFlow<LiveTripState> = TripTrackingService.liveState

    private val _settings = MutableStateFlow(UserSettings())
    val settings: StateFlow<UserSettings> = _settings

    val trips: StateFlow<List<TripEntity>> = tripDao.observeAllTrips()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val patternSummary: StateFlow<OverallPatternSummary> = combine(trips, settings) { list, cfg ->
        DrivingPatternAnalyzer.summarizeAllTrips(
            trips = list,
            speedLimitKmh = cfg.speedLimitKmh,
            useMph = cfg.useMph
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        DrivingPatternAnalyzer.summarizeAllTrips(emptyList(), 110f, false)
    )

    fun startTrip() {
        val cfg = _settings.value
        TripTrackingService.sendCommand(
            getApplication(),
            TripTrackingService.ACTION_START,
            cfg.harshBrakeThresholdMs2,
            cfg.speedLimitKmh
        )
    }

    fun pauseTrip() {
        TripTrackingService.sendCommand(getApplication(), TripTrackingService.ACTION_PAUSE)
    }

    fun resumeTrip() {
        TripTrackingService.sendCommand(getApplication(), TripTrackingService.ACTION_RESUME)
    }

    fun stopAndSaveTrip() {
        TripTrackingService.sendCommand(getApplication(), TripTrackingService.ACTION_STOP_AND_SAVE)
    }

    fun deleteTrip(tripId: Long) {
        viewModelScope.launch {
            tripDao.deleteTripById(tripId)
        }
    }

    fun toggleUnits() {
        _settings.value = _settings.value.copy(useMph = !_settings.value.useMph)
    }

    fun updateHarshBrakeThreshold(value: Float) {
        _settings.value = _settings.value.copy(harshBrakeThresholdMs2 = value)
    }

    fun updateSpeedLimitKmh(value: Float) {
        _settings.value = _settings.value.copy(speedLimitKmh = value)
    }
}
