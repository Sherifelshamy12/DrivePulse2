# DrivePulse — Android Driving Trip & Pattern Tracker (Kotlin + Jetpack Compose)

A complete v1 Android Studio starter project that tracks driving trips using **Fused Location Provider (GPS)** inside a **Foreground Service**, detects normal and harsh braking via the device's **Linear Accelerometer**, scores your **driving pattern**, and saves trips locally in **Room**.

## Option 1: Build the APK Automatically in the Cloud (No Android Studio Needed)
1. Unzip `DrivePulseAndroid.zip`.
2. Create a new repository on [GitHub](https://github.com/new) (public or private).
3. Upload all files and folders from inside `DrivePulseAndroid/` (making sure the `.github` folder is included) and commit them to `main`.
4. Open the **Actions** tab in your GitHub repo, wait ~2–3 minutes for **Build DrivePulse APK** to finish, and download **DrivePulse-debug-apk** under **Artifacts**.
5. Unzip the downloaded artifact on your Android phone and tap `app-debug.apk` to install (allow "Install from unknown sources" if prompted).

## Option 2: Build Locally in Android Studio
1. Unzip `DrivePulseAndroid.zip`.
2. Open **Android Studio** (Ladybug / 2024.2 or newer) -> **Open** -> select the `DrivePulseAndroid` folder.
3. Let Gradle sync finish (JDK 17, Android SDK 35, minSdk 26).
4. Click **Build -> Build Bundle(s) / APK(s) -> Build APK(s)** or click **Run** on a connected phone/emulator.

## Testing Without Driving (Android Emulator)
1. Start the app on an Android Emulator and tap **Start Trip**.
2. Open **Extended Controls (`...`) -> Location -> Routes**, pick two points, choose **Driving**, and click **Play Route**.
